const express = require("express");
const jwt = require("jsonwebtoken");
const app = express();
const secretkey = "secretkey";

app.get("/", (req, res) => {
  res.json({
    message: "a sample api",
  });
});

app.post("/login", (req, res) => {
  const user = {
    id: 1,
    username: "such",
    email: "dasuchandra.95@gmail.com",
  };

  jwt.sign({ user }, secretkey, { expiresIn: "300s" }, (error, token) => {
    res.json({
      token: token
    });
  });
});

function verifyToken(req,res,next)
{
    const bearerHeader=req.header['autherization'];
    if( typeof bearerHeader!='undefined'){
        const bearer=bearerHeader.split('');
        const token=bearer[1];
        req.token=token;
        next();
    }
    else {
        res.send({
            message:'invalid token'
        })
    }

}


app.post('/profile',verifyToken,(req,res)=>{
    jwt.verify(req.token,secretkey,(err,data)=>{
        if(err){
            res.send({
                result:'invalid token'
            })
        }
        else{
            res.json({
                message:'profile accessed',
                data
            })
        }
    })

})

app.listen(5000, () => {
  console.log("app is running");
});
