// const EventEmitter= require('events');

// class MyEmitter extends EventEmitter{}

// const eventEmitter= new MyEmitter();

// const sendMessage=(message)=>{
//     eventEmitter.emit("send notifications",message);
// }

// eventEmitter.on("send notifications",(message)=>{
//     console.log(message);
// });

// sendMessage("new message recvd");

                                                  //event driven architecture

const file= require('fs')
const path= require('path')
//const http= require('http')

const filepath= 'new file.txt';
const dataToWrite="hello suchandra";

file.writeFile(filepath,dataToWrite,(err)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log('Data written to file successfully.');
});

file.readFile(filepath,'utf8',(err,data)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log('Data written to file successfully.',data);
});

const normalize= path.normalize('path/to/../new file.txt');
const parse= path.normalize('path/to/new file.txt');
const filePath = path.resolve('MY NODE JS Project', 'new file.txt');
console.log(filePath);
//console.log(parse);

// const http = require('http');

// const options = {
//   hostname: 'www.example.com',
//   port: 80,
//   path: '/api/data',
//   method: 'GET'
// };

// const req = http.request(options, (res) => {
//   console.log(`Status code: ${res.statusCode}`);
//   res.setEncoding('utf8');
//   res.on('data', (chunk) => {
//     console.log(`Body: ${chunk}`);
//   });
// });

// req.on('error', (e) => {
//   console.error(`Problem with request: ${e.message}`);
// });

// req.end();

// const http = require('http');
// const server= http.createServer((req,res)=>{
//     res.writeHead('200',{'content-type':'text/plian'})
//     res.end('hello world');
// })

// server.listen('3000',()=>{
//     console.log('server running')
// })

                             //create server
const express=require('express');
const server=express();
const router=express.Router();

// router.get("/",(req,res)=>{
//     res.send("i am happy")
// })

// const middleware=(req,res,next)=>{
//     res.send('hello suchandra');
//     next();
// }
// server.use(middleware);
// server.listen(3000,()=>{
//     console.log("server is running");
// })
//module.exports=router;

    // create server using express.js middleware

// const authenticate=(req,res,next)=>{
//     if(req.headers.authorization==="my token"){
//         next();
//     }
//     else {
//         res.status(401).send('Unautorized');
//     }
// }

// router.get('/protected',authenticate,(req,res)=>{
//     res.send("this is protected route");
// })