const {fork}= require('child_process');

const subProcess= fork('./ChildProcess/Child.js')

subProcess.on('data',(data)=>{
    console.log(`data from child ${data}`)
})