const{spawn} =require('child_process');

const child= spawn('find',['.']);

child.stdout.on('data',(data)=>{
    console.log(data);
})

child.stderr.on('data',(data)=>{
    console.log(data);
})
child.on('error',(error)=>{
    console.log(error.message);
})

child.on('close',(data)=>{
    console.log(data);
})