setTimeout(()=>{
    process.send('Hello Parent')
},2000);