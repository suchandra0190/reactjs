const{exec} =require('child_process');

exec('ping google.com',(error,stdout, stderr)=>{

    if(error){
        console.log(error.message);
        return;
    }
    if(stdout){
        console.log(stdout);
        return;
    }

    if(stderr){
        console.log(stderr);
        return;
    }
})

url = "https://www.youtube.com/";
cmdCommand = `start chrome /new-tab ${url}`;
exec(cmdCommand);