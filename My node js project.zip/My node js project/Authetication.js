const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');

const app= express();
const port= 3000;

const secretKey='my-secret-key';

app.use(bodyParser.json());