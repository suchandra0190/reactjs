const express = require('express');
const session = require('express-session');
const app = express();

app.use(express.json());
app.use(session({
  secret: 'mysecret',
  resave: false,
  saveUninitialized: true
}));

// Dummy user data for demonstration purposes
const users = {
  alice: { password: 'password', role: 'admin' },
  bob: { password: 'password', role: 'user' }
};

// Simple login route to set session data
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users[role];
  
  if (user && user.password === password) {
    req.session.user = { username, role: user.role };
    return res.send('Logged in');
  }
  
  res.status(401).send('Invalid credentials');
});

// Simple logout route to destroy session data
app.post('/logout', (req, res) => {
  req.session.destroy();
  res.send('Logged out');
});

// Role-based middleware
function roleCheck(requiredRole) {
  return (req, res, next) => {
    if (!req.session.user) {
      return res.status(401).send('User not authenticated');
    }

    if (req.session.user.role !== requiredRole) {
      return res.status(403).send('Forbidden');
    }

    next();
  };
}

// Define routes
app.get('/admin', roleCheck('admin'), (req, res) => {
  res.send('Welcome, admin!');
});

app.get('/user', roleCheck('user'), (req, res) => {
  res.send('Welcome, user!');
});

app.get('/common', (req, res) => {
  res.send('Welcome, all users!');
});

// Start the server
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
