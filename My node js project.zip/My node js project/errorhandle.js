const fs= require('fs');

fs.readFile('Hello.txt',(err,data)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log(data);
});
//callback

const fs = require('fs').promises;

fs.readFile('file.txt')
  .then(data => {
    // Process data
    console.log(data);
  })
  .catch(err => {
    // Handle error
    console.error('Error reading file:', err);
  });

  //promise

  const fs = require('fs').promises;

  async function readFile(){
    try{
        const data=fs.readFile('file.txt');
        console.log(data);
    }
    catch(err){
        console.log(err);
    }
  }

  readFile();

  //async/await

  const evenEmitter=require('events');
const { error } = require('console');
  const emitter=new evenEmitter();
  emitter.on('err',(err)=>{
    console.log(err);
  });

  emitter.emit('error',new error('something went wrong'));

  //event

  process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
  });
  
  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled promise rejection:', reason);
  });

//global error handling
