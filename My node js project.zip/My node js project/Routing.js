const express= require('express')
const app= express();

app.get('/user',(req,res)=>{
    res.send('Hi I am suchandra')
})

app.listen('3000',()=>{
    console.log('server is running')
})

function logrequest(req,res,next){
    console.log('hi')
    next();
}

app.use(logrequest);

app.get('/protected',(req,res)=>{
    console.log('this is protected url');
})