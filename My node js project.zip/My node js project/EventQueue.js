
function add(callby,x,y){
    console.log(callby,":",x+y)
}

setImmediate(()=>{
    add('setimmediate',2,3);
})

//check queue for next cycle

setTimeout(() => {
    add("setTimeout",3,4)
}, 0);
//timer queue

add('direct',1,2)

console.log('Start');

setTimeout(() => {
  console.log('Timeout');
}, 0);

setImmediate(() => {
  console.log('Immediate');
});

process.nextTick(() => {
  console.log('Next Tick');
});

Promise.resolve().then(() => {
  console.log('Promise');
});

console.log('End');


