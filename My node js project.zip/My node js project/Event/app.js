// const dbfile= require('./Dbfile');
// const {loginSuccessful}= require('./Login');

// const{myEventEmitter,LOGIN_EVENT}= require("./eventFile");

// myEventEmitter.on(LOGIN_EVENT,(userName)=>{
//     console.log('sending email to :', userName);
// })

// loginSuccessful('suchandra');

const EventEmitter= require('events');

const eventEmitter= new EventEmitter();

const sendMessage=(message)=>{
    eventEmitter.emit("send notifications",message);
}

eventEmitter.on("send notifications",(message)=>{
    console.log(message);
});

sendMessage("new message recvd");



