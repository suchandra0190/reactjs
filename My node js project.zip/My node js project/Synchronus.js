const fs= require('fs');

const data=fs.readFileSync('EventQueue.js','utf8');
console.log(data);

console.log('this will log after file content');

//synchronus file read

// const fs= require('fs');

// fs.readFile('EventQueue.js','utf8',(err,data)=>{  //error-first callback
//     if(err){
//         return console.log(err);
//     }
//     console.log(data)

// });
// console.log('this will log before file content');


// const fs = require('fs').promises;

// fs.readFile('example.txt', 'utf8')
//   .then(data => {
//     console.log(data);
//   })
//   .catch(err => {
//     console.error(err);
//   });

// console.log('This will log before the file content');


// const fs = require('fs').promises;

// async function readFileAsync() {
//   try {
//     const data = await fs.readFile('Hello.txt', 'utf8');
//     console.log(data);
//   } catch (err) {
//     console.error(err);
//   }
// }

// readFileAsync();

// console.log('This will log before the file content');

