// const express=require('express');
// const app=express();
// const path=require('path');

// app.set('view engine','ejs');
// app.set('views',path.join(__dirname,'views'));

// app.get('/',(req,res)=>{
//     res.render('index',{title:'node.js with EJS'})
// })
// app.listen('3000',(req,res)=>{
//     console.log("ejs running");
// })

const http = require('http');

// Create the server
const server = http.createServer((req, res) => {
  // Set the response status code and headers
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  
  // Send the response body and close the connection
  res.end('Hello, World!\n');
});

// Define the port to listen on
const port = 3000;

// Start the server and listen on the specified port
server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});


const express = require('express');

// Create an instance of an Express application
const app = express();


// Define a simple route
app.get('/', (req, res) => {
  res.send('Hello, World!');
});

// Start the server and listen on the defined port
app.listen(3000, () => {
  console.log(`Server running at http://localhost:${port}/`);
});