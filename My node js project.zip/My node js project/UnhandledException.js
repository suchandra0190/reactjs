const express= require('express')
const app= express();


process.on('uncaughtexception',(error)=>{
    console.error(error);
    process.exit(1);
})

process.on('unhandleexception',(reason,promise)=>{
    console.error(reson);
});

app.use((err,req,res,next)=>{
    console.error(err.message);
    res.status(500).send('something went wrong');
})




