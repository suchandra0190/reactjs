
import React, { useState, useRef } from "react";

const UnControlledComponent = () => {
  const myRef = useRef(null);

  const submitForm=(event)=>{
    event.preventDefault();
    console.log(myRef.current.value)  //form data is handled by the DOM itself. 
    //Refs are used to access the form element values. 
         //The form elements maintain their own state.
  }

  return (
    <div>
      <form onSubmit={submitForm}>
        <input type="text" ref={myRef}></input>
        <button type='submit'>submit</button>
      </form>
     
    </div>
  );
};

export default UnControlledComponent;
