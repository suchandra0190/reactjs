
// maintain its own state locally
// takes value through state and props

import { useState } from "react";

const ControlledComponent=()=>{

const[value,setValue]=useState(null);

const handleOnchange=(event)=>{
    setValue(event.target.value)
}   //form data is handled by the React component state.

return(
    <div>
        <input type="text" value={value} onChange={(e)=>handleOnchange(e)}></input>
        <h1>{value}</h1>
    </div>
)

}

export default ControlledComponent;