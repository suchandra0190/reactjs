import React from 'react'

const Button=({label,onClick})=>{
    <Button onClick={onclick}>{label}</Button>
}

export default Button;