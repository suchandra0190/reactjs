import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Button from './Button';

test('render buttons with provided label',()=>{
    render(<Button label='Click me'/>);
    const buttonElement= screen.getByText(/Click me/i);
    expect(buttonElement).toBeInTheDocument();
})

test('render buttons clicks',()=>{
    const handleClick= jest.fn()
    render(<Button label='Click me' onClick={handleClick}/>);
    const buttonElement= screen.getByText(/Click me/i);
    fireEvent.click(buttonElement)
    expect(buttonElement).toHaveBeenCalledTimes(1);
})