import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Counter from './Counter';

test('testing the count is incrementing',()=>{

    render(<Counter/>);

    const initialCount=screen.getByText(/count:0/i);
    expect(initialCount).toBeInTheDocument();

    const buttonClick=screen.getByText(/increment/i);
    fireEvent.click(buttonClick);

    const updatedState= screen.getByText(/count:1/i);
    expect(updatedState).toBeInTheDocument();

})