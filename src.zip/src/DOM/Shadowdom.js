{/* <div id="main">
  <my-component></my-component>
</div>

<script>
  class MyComponent extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
      shadow.innerHTML = `
        <style>p { color: red; }</style>
        <p>Hello from Shadow DOM</p>
      `;
    }
  }

  customElements.define('my-component', MyComponent);
</script> */}
