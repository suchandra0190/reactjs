// React component example using Virtual DOM
function MyComponent() {
    const [count, setCount] = React.useState(0);
  
    return (
      <div>
        <p>{count}</p>
        <button onClick={() => setCount(count + 1)}>Increment</button>
      </div>
    );
  }
  