import { useState } from "react";
const data=[ { id: 1, name: "apple" },
{ id: 2, name: "banana" },
{ id: 2, name: "grape" },
{ id: 2, name: "mango" },]

const SerachfilterNew = () => {

  const [filtereddata, setFiltereddata] = useState(data);

  const [count, setCount] = useState(0);

  const handleChange = (e) => {
    if (e.target.value === "") {
      setFiltereddata(data);
    } else {
      setFiltereddata((filterData) => {
        return [...filterData].filter(
          (item) =>
            item.name.toLowerCase().indexOf(e.target.value.toLowerCase())!==-1
        );
      });
    }
  };

  // const handleClick=()=>{
  //   setCount(count+1);
  //   setCount(count=>{
  //        return count+1   // if it has any dependency
  //   })
  //   setCount(count=>count+1);
  // }
  
  return (
    <div>
      <input type="text" placeholder="Serach.." onChange={handleChange}/>
      <ul>
        {filtereddata?.map((value,index) => <li key={index}>{value.name}</li>)}
      </ul>
    </div>
  );
};

export default SerachfilterNew;


