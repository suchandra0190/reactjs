import { useState, useEffect } from "react";

const CreateTableNew = () => {
  const [data, setDataRow] = useState([]);
  const [dataCol, setDataCol] = useState([]);

  const handleClickRow = () => {
    const userInput = document.getElementById("row").value;
    if (userInput) {
      const newdata = [...data, userInput];
      setDataRow(newdata);
      return newdata;
    }
  };

  const handleClickCol = () => {
    const userInput = document.getElementById("col").value;
    if (userInput) {
      const newdata = [...dataCol, userInput];
      setDataCol(newdata);
      return newdata;
    }
  };

  return (
    <div>
      <input type="text" id="row"></input>
      <button onClick={handleClickRow}>Add Row</button>
      <input type="text" id="col"></input>
      <button onClick={handleClickCol}>Add Column</button>
      <div>
        <table>
          <thead>
            <tr>
              {dataCol.map((value, key) => (
                <th key={key}>{value}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((value, key) => (
              <tr key={key}>
                <td>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CreateTableNew;
