import React, { useState } from 'react';


function Createtable() {
  const [columns, setColumns] = useState([]);
  const [rows, setRows] = useState([]);
  const [newColumnName, setNewColumnName] = useState('');
  const [newRowData, setNewRowData] = useState({});
  const [columnError, setColumnError] = useState('');
  const [rowError, setRowError] = useState('');

  const handleColumnChange = (e) => {
    setNewColumnName(e.target.value);
  };

  const handleRowChange = (e) => {
    const { name, value } = e.target;
    setNewRowData({ ...newRowData, [name]: value });
  };

  const handleAddColumn = (e) => {
    e.preventDefault();
    if (newColumnName.trim() === '') {
      setColumnError('Column name cannot be empty');
      return;
    }
    setColumns([...columns, newColumnName.trim()]);
    setNewColumnName('');
    setColumnError('');
  };

  const handleAddRow = (e) => {
    e.preventDefault();
    if (columns.length === 0) {
      setRowError('Please add at least one column first');
      return;
    }
    const newRow = columns.reduce((row, col) => {
      row[col] = newRowData[col] || '';
      return row;
    }, {});
    setRows([...rows, newRow]);
    setNewRowData({});
    setRowError('');
  };

  return (
    <div className="App">
      <h1>Dynamic Table with React</h1>
      <form onSubmit={handleAddColumn}>
        <input
          type="text"
          placeholder="New Column Name"
          value={newColumnName}
          onChange={handleColumnChange}
        />
        <button type="submit">Add Column</button>
        {columnError && <span className="error">{columnError}</span>}
      </form>
      <form onSubmit={handleAddRow}>
        {columns.map((col) => (
          <input
            key={col}
            type="text"
            placeholder={`Value for ${col}`}
            name={col}
            value={newRowData[col] || ''}
            onChange={handleRowChange}
          />
        ))}
        <button type="submit">Add Row</button>
        {rowError && <span className="error">{rowError}</span>}
      </form>
      <table>
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col}>{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index}>
              {columns.map((col) => (
                <td key={col}>{row[col]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Createtable;
