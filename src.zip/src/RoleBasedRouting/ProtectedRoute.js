import { Route } from "react-router";

const ProtectedRoute = ({ component: Component, ...rest }) => {
    const auth = useAuth();
  
    return (
     <Route
        {...rest}
        render={(props)=>{
            auth.isAuthenticated?
            (<Component {...props}/>):
            (<Redirect to='/Login'/>)

        }}

     />
    );
  };
  