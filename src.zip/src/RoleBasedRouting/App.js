import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import Dashboard from './Dashboard';
import AdminPanel from './AdminPanel';
import Profile from './Profile';
import Login from './Login';
import NotAuthorized from './NotAuthorized';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Switch>
          <ProtectedRoute path="/dashboard" component={Dashboard} />
          <RoleProtectedRoute path="/admin" component={AdminPanel} role="admin" />
          <ProtectedRoute path="/profile" component={Profile} />
          <Route path="/login" component={Login} />
          <Route path="/not-authorized" component={NotAuthorized} />
        </Switch>
      </Router>
    </AuthProvider>
  );
}

export default App;
