import React,{createContext,useContext,useState} from "react"

const context= React.createContext();
export const AuthContext=({children})=>{

    const[state, setState]=useState({
        isAuthenticated: true,
        role:'guest'});



    return(
        <context.Provider value={state}>
            {children}
        </context.Provider>
    )

}

export const useAuth=()=>{
    return useContext(AuthContext);
}

 export default AuthContext