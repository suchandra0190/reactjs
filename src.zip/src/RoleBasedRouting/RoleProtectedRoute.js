const RoleProtectedRoute = ({ component: Component, role, ...rest }) => {
    const auth = useAuth();
  
    return (
      <Route
        {...rest}
        render={(props) =>
          auth.isAuthenticated && auth.role === role ? (
            <Component {...props} />
          ) : (
            <Redirect to="/not-authorized" />
          )
        }
      />
    );
  };
  