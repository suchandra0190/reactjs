export const fetchDataRequest = () => ({
  type: "FETCH_DATA_REQUEST",
});

export const fetchDataSucess = (data) => ({
  type: "FETCH_DATA_SUCESS",
  payload: data,
});

export const fetchDataFaliure = (error) => ({
  type: "FETCH_DATA_FALIURE",
  payload: error,
});

export const fetchData = () => {
  return async (dispatch) => {
    dispatch(fetchDataRequest);
    try {
      const response = await fetch("....apiurl");
      const data = response.json();
      dispatch(fetchDataSucess(data));
    } catch (error) {
      dispatch(fetchDataFaliure(error));
    }
  };
};
