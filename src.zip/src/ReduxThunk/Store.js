import { createStore, applyMiddleware,combineReducers } from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './reducers';

const rootReducer= combineReducers({
    auth: authReducer,
    products: productReducer
})

///multiple reducer

const store=createStore(rootReducer, applyMiddleware(thunk))