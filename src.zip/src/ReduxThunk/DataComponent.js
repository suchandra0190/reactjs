import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchData } from "./actions";

const dataComponent = () => {
  const dispatch = useDispatch();
  const { loading, data, error } = useSelector((state) => state.reducer);

  useEffect =
    (() => {
      dispatch(fetchData());
    },
    [dispatch]);
};

if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <ul>
      {data.map((item) => (
        <li key={item.id}>{item.name}</li>
      ))}
    </ul>
  );

export default dataComponent;
