import React, { Component, useState } from 'react'

const HOC=(Component)=>{
    return function ModifiedComponent(props){
        const[count,setCount]=useState(0);
        return(
            <Component {...props} count={count} increment={()=>setCount(count+1)} name="Tuhin"/>
        )
    }
}

export default HOC;





