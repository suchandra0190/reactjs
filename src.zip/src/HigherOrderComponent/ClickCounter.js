import React, { Component, useState } from 'react'
import HOC from './HOC'
import NameHOC from './NameHOC'

const ClickCounter=(props)=>{

    const{count, increment,name}=props;
   
    return(
        <div>
            <h1>Count:{count}</h1>
            <button onClick={increment}>Click me</button>
            <h2>My name is: {name}</h2>
        </div>
    )
}
export default NameHOC(HOC(ClickCounter));