import React, { useState } from 'react'

const NameHOC=(Component)=>{
    return function ModifiedComponent(props){
        const[count,setCount]=useState(0);
        return(
            <Component {...props} name="Suchandra"/>
        )
    }
}
export default NameHOC;