import React from 'react';

const Greeting = (props) => {
  return (
    <div>
      <h1>Hello, {props.name}!</h1>
      <p>Welcome to {props.location}.</p>
    </div>
  );
};

//without destructuring

// export default Greeting;

import React from 'react';

const Greeting1 = ({ name, location }) => {
  return (
    <div>
      <h1>Hello, {name}!</h1>
      <p>Welcome to {location}.</p>
    </div>
  );
};

//with destructuring
export default Greeting1;

