// function add(a:number,b:number){
//     return a+b;
// }

// console.log(add(2,'10')) //

const user: { name: string, age: number } = { name: 'suchandra', age:29 };

// IntelliSense will suggest 'name' and 'age' when you type user.


interface User {
    name: string;
    age: number;
  }
  
  function greetUser(user: User): string {
    return `Hello, ${user.name}!`;
  }
  