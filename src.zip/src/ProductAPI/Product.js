import React,{ useEffect, useState } from "react";
import axios from "axios";

const Product = () => {
  const [product, setProduct] = useState([]);

  const apiurl = "https://fakestoreapi.com/carts/2";
  const productDetailsAPI='https://fakestoreapi.com/products/'

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await axios.get(apiurl);
        const data = response.data.products;
        const productDetailsPromises =data.map(async (value,key)=>{
            const fetchProductDetails= await axios.get(productDetailsAPI+value.productId);
            return fetchProductDetails.data;
        })

        const productDeatils= await Promise.all(productDetailsPromises);
        console.log(productDeatils)
        setProduct(productDeatils)
        
      } catch (error) {
        console.log(error);
      }
    };

    fetchProduct();
  }, []);

  return (
    <div>
      <h1>Products</h1>
      <ul>
        {product.map((product,index)=>{
            return<li key={index}>
            <h3>{product.title}</h3>
            <p>Price: ${product.price}</p>
            <img src={product.image} alt={product.title} />
          </li> 
        })}
      </ul>
    </div>
  );
};

export default Product;
