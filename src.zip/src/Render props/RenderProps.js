// function DataFetcher({ render }) {
//     const [data, setData] = useState(null);
  
//     useEffect(() => {
//       // Simulate fetching data
//       setTimeout(() => {
//         setData({ message: 'Hello from Render Props' });
//       }, 1000);
//     }, []);
  
//     return render(data);
//   }
  
//   function App() {
//     return (
//       <DataFetcher
//         render={(data) => (
//           data ? <div>{data.message}</div> : <div>Loading...</div>
//         )}
//       />
//     );
//   }
  