import React,{useState} from 'react'
const Input=(props)=>{
    const[value,setValue]=useState('');
    const handleChange=(e)=>{
        setValue(e.target.value);
    }

    return(
        <div>
            <Input value={value} onChange={(e)=>handleChange(e)}></Input>
            {props.renderText && props.renderText(value)}
        </div>
    )

}

export default Input;