<div id="parent">
  <button id="child">Click Me</button>
</div>

document.getElementById("parent").addEventListener("click", () => {
    console.log("Parent clicked");
  });
  
  document.getElementById("child").addEventListener("click", (event) => {
    console.log("Child clicked");
  });

//click event of child div will bubble up to the parent div

document.getElementById("parent").addEventListener("click", () => {
    console.log("Parent clicked");
  });
  
  document.getElementById("child").addEventListener("click", (event) => {
    event.stopPropagation(); // Stops the event from bubbling up
    console.log("Child clicked");
  });

  //now it will not log the parent div