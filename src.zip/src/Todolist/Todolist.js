import React, { useState, useCallback, useEffect } from "react";

const TodoList = (props) => {
    const todoListArray=[ { isChecked: false, name: "appgole" },
    { isChecked: false, name: "banana" },
    { isChecked: false, name: "grape" },
    { isChecked: false, name: "mango" },]

  const[arrayCopy,setarrCopy]=useState(todoListArray);

  const handleOnclick=(index)=>{
    setarrCopy((arrayCopy) => {
      const newArray = [...arrayCopy]; // Create a copy of the array
      if (newArray[index].isChecked) {
        const filteredArray = newArray.filter((_, i) => i !== index); // Filter out the item at the specified index
        return filteredArray;
      }
      return newArray; // Return the original array if the item is not checked
    });
  }

  const handleCheckbox=((index)=>{
    console.log(index)
    setarrCopy((arrayCopy)=>{
        const newChcekdItems=[...arrayCopy];
        newChcekdItems[index]={ ...newChcekdItems[index], isChecked: !newChcekdItems[index].isChecked }
        return newChcekdItems;
    });
  })

  const addClicked=()=>{
    const userData=document.getElementById('text').value;
    var isExist= arrayCopy.map(item=>item.name).includes(userData);
    if(!isExist){
      const userDataArray=[...arrayCopy,{isChecked:false, name:userData}];
      setarrCopy(userDataArray);
      localStorage.setItem('addtodo',JSON.stringify(userDataArray));
    }  
  }

  useEffect(()=>{
    const data= localStorage.getItem('addtodo');
    if(data){
      setarrCopy(JSON.parse(data));
    }
  },[])

  
  return (
    <div>
      <input type='textbox' id='text'/>
      <button onClick={addClicked}>add</button>
      <ul>
        {arrayCopy.map((el,i) => {
          return (
            <li key={i}>
            <input type="checkbox" onChange={()=>handleCheckbox(i)} checked={el.isChecked}></input>
              {el.name}
              <button onClick={()=>handleOnclick(i)}>Delete</button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};
export default TodoList;
