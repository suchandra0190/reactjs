import { useState,useEffect } from "react"

const TodoListPractice=()=>{

    const todolistArray=[{name:'Cricket',id:1, isChecked:false},
        {name:'Tennis',id:2, isChecked: false},
        {name:'Ludo',id:3, isChecked: false},
        {name:'Football',id:4, isChecked: false}
    ]

    const[array,setArray]=useState(todolistArray);
   

    const handleOnchange=(e)=>{
        setArray((prevArray)=>{
            const checkedItems=[...prevArray];
            checkedItems[e]={...checkedItems[e], isChecked:!checkedItems[e].isChecked}
            console.log(checkedItems)
            return checkedItems;
        })
    }

   

    const handleClick=(index)=>{
        setArray((prevArray)=>{
            const newArray=[...prevArray];
            if(newArray[index].isChecked){
                const filteredArray=newArray.filter((_,i) => i!==index);
                return filteredArray;
            }
            return newArray
        })
    }


  
    const addClicked=()=>{
        const userInput=document.getElementById('text').value;
        var isExist=array.map(item=>item.name).includes(userInput);
        if(!isExist){
            const addedData=[...array,{isChecked:false, name: userInput}];
            setArray(addedData);
            localStorage.setItem('addTodoNew',JSON.stringify(addedData));

        }
    }
    useEffect(()=>{
        const data= localStorage.getItem('addTodoNew');
        if(data){
          setArray(JSON.parse(data));
        }
      },[])
    

    return(

        <div>
            <ul>
                <input type='text' id='text'></input>
                <button onClick={addClicked}>add</button>
                {array.map((value,key)=>{
                    return (<li key={key}>
                        <input type='checkbox' onChange={()=>handleOnchange(key)} checked={value.isChecked}></input>
                         {value.name}
                         <button onClick={()=>handleClick(key)}>delete</button>
                         </li>);
                })}
            </ul>
        </div>

    )

}

export default TodoListPractice;