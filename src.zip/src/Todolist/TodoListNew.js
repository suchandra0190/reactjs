import React, { useState, useCallback, useEffect } from "react";

const TodoListNew = (props) => {
    const todoListArray=[ { id:1, isClicked: false, name: "appgole" },
    { id:2, isClicked: false, name: "banana" },
    { id:3,  isClicked: false, name: "grape" },
    { id:4,  isClicked: false, name: "mango" },]

    const[todolistdata, setTodolistdata]=useState(todoListArray);
    const[inprogressdata, setInprogressdata]=useState([]);
    const[completedData, setCompletedData]=useState([]);

    const handleOnclick=(value,i)=>{
      const checkedItems=[...todolistdata];   //shallowcopy
      checkedItems[i]={...checkedItems[i], isClicked: true } //object spreading
      if(checkedItems[i].isClicked){
        let indexOfRemovedItem=checkedItems.indexOf(checkedItems[i])
        const removeDatafromTodoList= checkedItems.filter((_,index)=>{
          return i!=index;
        })
        setTodolistdata(removeDatafromTodoList);
        setInprogressdata([...inprogressdata, {...checkedItems[indexOfRemovedItem], isClicked: false}]);
        return removeDatafromTodoList; 
      }
    }

    const handleOnclickInprogrss=(value,i)=>{
      const checkedItems=[...inprogressdata];
      checkedItems[i]={...checkedItems[i], isClicked: true }
      if(checkedItems[i].isClicked){
        let indexOfRemovedItem=checkedItems.indexOf(checkedItems[i])
        const removeDatafromInprogress= checkedItems.filter((_,index)=>{
          return i!=index;
        })
        setInprogressdata(removeDatafromInprogress);
        setCompletedData([...completedData, checkedItems[indexOfRemovedItem]]);
        return removeDatafromInprogress; 
      }
    }
 
  return (
    <div style={{display:'flex'}}>
     <ul>
      <h1>Todo</h1>
        {todolistdata.map((value,index)=>{
            return<li key={value.id} onClick={(e)=>handleOnclick(value.name,index)}>{value.name}</li>
        })}
     </ul>
     <ul>
     <h1>In progress</h1>
     {inprogressdata.map((value,index)=>{
            return<li key={value.id} onClick={(e)=>handleOnclickInprogrss(value.name,index)}>{value.name}</li>
        })}
     </ul>
  
     <ul>
     <h1>Completed</h1>
     {completedData.map((value,index)=>{
            return<li key={value.id} onClick={(e)=>handleOnclickInprogrss(value.name,index)}>{value.name}</li>
        })}
     </ul>
    </div>
  );
};
export default TodoListNew;
