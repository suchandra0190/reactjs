import React, { useEffect } from 'react';
import _ from 'lodash';

const ThrottlingExample = () => {
  // Throttled function
  const handleScroll = _.throttle(() => {
    console.log('Scroll event triggered');
    // Place your logic here
  }, 1000); // 1000ms = 1 second

  useEffect(() => {
    // Add event listener
    window.addEventListener('scroll', handleScroll);

    // Clean up the event listener on component unmount
    return () => {                                      // component unmount
      window.removeEventListener('scroll', handleScroll);
    };
  }, [handleScroll]);

  return (
    <div style={{ height: '1500px', padding: '20px' }}>
      <h1>Scroll down to see the throttled effect</h1>
    </div>
  );
};

export default ThrottlingExample;
