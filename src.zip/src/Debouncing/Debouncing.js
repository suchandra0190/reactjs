import { useState, useEffect } from "react";
import axios from "axios";
const Debouncing = () => {
  const [pin, setPin] = useState(null);

  const apiUrl = "https://api.postalpincode.in/pincode/";

  useEffect(() => {
    const debouncing=setTimeout(() => {
      axios
        .get(apiUrl)
        .then((res) => {
          console.log(res);
        })
        .catch((error) => {
          console.log(error);
        });
    }, 2000)
    return(()=>{
        clearTimeout(debouncing)
    })
  }, [pin]);

  return (
    <div>
      <input
        type="text"
        onChange={(event) => setPin(event.target.value)}
      ></input>
    </div>
  );
};

export default Debouncing;
