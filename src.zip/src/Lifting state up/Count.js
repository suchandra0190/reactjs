const Count=({count})=>{

    return(
        <div>
            Count is {count}
        </div>
    )

}

export default Count;