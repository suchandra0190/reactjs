import { useState } from "react";
const Child = ({ data, DataFromChild }) => {
  const handleClick = () => {
    DataFromChild("Hi from child");
  };
  return (
    <div>
      <h1>{data}</h1>
      <button onClick={handleClick}>send data</button>
    </div>
  );
};

export default Child;
