import { useState } from "react";
import Child from "./Child";
const Parent = () => {
  const [data, setData] = useState(null);
  const [data1, setData1] = useState(null);

  const handleClick = () => {
    const data = "hi from Parent";
    setData1(data);
  };

  const handleData = (data) => {
    setData(data);
  };
  return (
    <div>
      <h1>{data}</h1>
      <button onClick={handleClick}>send data to child</button>
      <Child DataFromChild={handleData} data={data1} />
    </div>
  );
};

export default Parent;
