function add(a){
    return function(b){
        return function (c){
            return a+b+c;
        }
    }
}

console.log(add(1)(2)(8)) //11

//currying

function mul(a,b){
    return a*b;
}

const newfunc= mul.bind(null,2); //Here, newfunc is a new function where 2 is pre-set as the first argument to multiply.
console.log(newfunc(8)) //16

//bind

function add(a) {
    return function(b) {
        return function(...args) {
            // Sum a, b, and all additional arguments
            return a + b + args.reduce((sum, num) => sum + num, 0);
        }
    }
}

console.log(add(1)(2)(6,8,9,7)); // Output: 33


const name='suchandra';
const age=24;

const person={name,age}
console.log(person.name)

//object literals

function Person() {
    this.age = 0;

    setInterval(() => {
        this.age++; // `this` refers to the Person object
        console.log(this.age);
    }, 1000);
}

const person1 = new Person(); //with arrow function

function Person() {
    this.age = 0;

    setInterval(function() {
        this.age++; // `this` refers to the global object (or `undefined` in strict mode)
        console.log(this.age);
    }, 1000);
}

const person2 = new Person(); // This won't work as expected


"use strict"

function sum(a,a,b){
    return a+a+b;
}

console.log(sum(2,2,4)) //Duplicate parameter name not allowed in this context

//without usestrict it will give result 8


