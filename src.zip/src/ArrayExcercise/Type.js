console.log(typeof +'12') //number
console.log(typeof NaN) //number
console.log(+'Hi') //NaN
console.log(NaN===NaN)//false 
console.log('5'+3) //53
console.log('5'-3) //2
console.log(1<2<3) //true   //1<2= true, true<3=1<3=true
console.log(3>2>1) //false  //3>2=true, true>1=1>1=false

