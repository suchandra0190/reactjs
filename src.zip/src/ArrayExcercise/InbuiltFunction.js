const numbers=[2,16,18,9]

const ln= numbers.some(item=>item>10); //check atleast one num is greater than 10

console.log(ln) //true

const l= numbers.every(item=>item>10); //check all num is greater than 10

console.log(ln) //false

function add(...numbers){
    return numbers.reduce((total,num)=> total+num)
}

console.log(add(2,3,4)) //9

