const arr = [-3, 8, 7, 6, 5, -4, 3, 2, 1];

function bubblesort(arr){
    for(let i=0;i<arr.length;i++){
        for(let j=0;j<arr.length-1-i;j++){
            if(arr[j]>arr[j+1]){
                let temp=arr[j];
            arr[j]=arr[j+1];
            arr[j+1]=temp;
            }
            
        }
    }
    return arr;
}

const sortedArray=bubblesort(arr)
console.log(sortedArray)

//sorting an array



array=[1,3,10,11,14]
goal=13    //output will be index
output=[1,2]

let arr1=[];

for(i=0;i<array.length;i++){
        if(array[i]+array[i+1]==goal){
            arr1.push(array.indexOf(array[i]));
            arr1.push(array.indexOf(array[i+1]))
    }
}
console.log(arr1)

////////////////////////////////////////////////////////////////
let products=[
    {product:'milk', quantity: 3, price: 1.50},
    {product:'milk', quantity: 4, price: 4.50}
]

//calculate total price
let sum=0;

products.forEach((item=>{
    sum+=item.quantity*item.price
}))

console.log(sum)

//////////////////////////////////////////////////////////////////////////////////////


const array=[{
    name:'suchandra',
    id:1,
    address:{
        name:'sanchita',
        pin:'742224',
        place:'kolkata'
    }
},
{
    name:'tuhin',
    address:[{
        name:'sudeshna',
        place:'burdwan'
    },
    {
        name:'vul'
    }]
   
}]

const name=[]

array.forEach(item=>{
    name.push(item.name);
    

if(Array.isArray(item.address)){
    item.address.forEach(item=>{
        name.push(item.name)
         
    })
}
else if(typeof item.address==='object'){
   name.push(item.address.name)
}

console.log(name)
})


const numbers=[1,2,3]

const output=numbers.map(num=>num*2);

console.log(output)  //[2,4,6]  new array with tranformed element


const numbers2=[1,2,3]

numbers2.forEach(num=>console.log(num*2)); //Use it when you need to perform an action for each element in an array,
// and you don't need a new array as a result.

const numbers6=[1,2,3,8,9,4,22,90]

const output8=numbers.filter((num)=>num%2==0);

console.log(output)  //returns array with different length