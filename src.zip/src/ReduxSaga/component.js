import React from 'react';
import { useDispatch } from 'react-redux';

const MyComponent = () => {
  const dispatch = useDispatch();

  const handleFetchData = () => {
    dispatch({ type: 'FETCH_DATA_REQUESTED' });
  };

  return (
    <div>
      <button onClick={handleFetchData}>Fetch Data</button>
    </div>
  );
};

export default MyComponent;
