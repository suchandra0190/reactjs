import { call, put, takeEvery } from 'redux-saga/effects';

function fetchData(){
    return fetch('')
    .then((response=>response.json())
    .catch(error=> {throw error})
)}

function *fetchDataSaga(){
    try{
        const data=yield call(fetchData);
        yield put({
            type:'FETCH_DATA_SUCESS',payload:data
        })
    } catch(error){
        yield put({
            type:'FETCH_DATA_FALIURE',payload:error
        })
    }
}

function watcherSaga(){
    yield takeEvery('FETCH_DATA_REQUESTED',fetchDataSaga)
}

export default function rootSaga(){
    yield all([
        watcherSaga()
    ])
}
