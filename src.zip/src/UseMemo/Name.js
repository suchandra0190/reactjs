import React,{useEffect, useState} from 'react'

const Name=({name})=>{
    console.log("name")
 return (
    <div>
       Name is {name}
    </div>
 )
}

export default React.memo(Name);