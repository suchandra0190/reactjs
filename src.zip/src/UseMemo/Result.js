import React,{useEffect, useState, useMemo} from 'react'

const Result=({marks,subject})=>{
   console.log("result")

   const percentageMarks= useMemo(()=>{
    console.log("inside usememo")
    return (marks*100)/100;
   },[marks] 
   )
  
 return (
    <div>
       Marks is {marks}
       percentageMarks is {percentageMarks}
       subject is {subject}
    </div> 
 )
}

export default React.memo(Result);