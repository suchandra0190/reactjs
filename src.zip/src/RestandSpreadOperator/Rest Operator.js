function multiply(multiplier, ...args){
    return args.map(arg=>arg* multiplier)
}

console.log(multiply(2,3,6,8));  //rest parameter(function defintion)

function greet(...args){
    console.log(...args) //rest parameter
}

const names=['A','B','C']
greet(...names)  // spread operator