import React, { useState, lazy, Suspense } from "react";
import axios from "axios";
const Dashboard = () => {
  const [isUserLoaded, setisUserLoaded] = useState(false);

  const User = lazy(() => import("./User"));

  const loaduser = () => {
    setisUserLoaded(true);
  };

  return (
    <div>
      <button onClick={() => loaduser()}>Load User</button>
      {isUserLoaded ? (
        <Suspense fallback={<div>Loading....</div>}>
          <User />
        </Suspense>
      ) : (
        <div>Click the button to load user data.</div>
      )}
    </div>
  );
};

export default Dashboard;
