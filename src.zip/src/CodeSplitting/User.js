import React, { useEffect, useState } from "react";
import axios from "axios";
const User = () => {
  const [user, setUser] = useState(null);

  const apiUrl = "https://dummyjson.com/users";
  useEffect(() => {
    axios
      .get(apiUrl)
      .then((res) => {
        const userList = res.data.users;
        setUser(userList);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  if (!user) {
    return <div>Loading...</div>;
  }
  return (
    <div>
      <ul>
        {user.map((value, key) => (
          <li key={key}>{value.firstName}</li>
        ))}
      </ul>
    </div>
  );
};

export default User;
