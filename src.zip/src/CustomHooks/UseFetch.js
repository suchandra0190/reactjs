import React, { useEffect, useState } from "react";

export const UseFetch = () => {
  const [products, setProducts] = useState({});

  const getProductDetails = async () => {
    const proxyUrl = 'https://cors-anywhere.herokuapp.com/';
    const apiUrl = 'https://jsonplaceholder.typicode.com/todos/1';
    const producDetails = await fetch(proxyUrl + apiUrl);
    console.log(producDetails)
    const producDetailsJSON = await producDetails.json;
    setProducts(producDetailsJSON);
    console.log(products);
  };
  useEffect(() => {
    getProductDetails();
  }, []);

  return { products };
};
