import React,{useEffect, useState} from 'react'
import { UseFetch } from './UseFetch';

const ProductDetails=()=>{
    const{products}=UseFetch();
    console.log(products)

return(
    <div>
        {/* {products.map(product => <div>{product.title}</div>)} */}
    </div>
)
    

}


export default ProductDetails;