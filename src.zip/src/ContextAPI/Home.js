import React,{useEffect, useState} from 'react'
import Profile from './Profile';
const Home=()=>{
    
return(
    <div>
        <Profile/>
    </div>
)
}


export default Home;