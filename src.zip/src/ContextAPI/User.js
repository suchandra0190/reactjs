import React,{useEffect, useState,useContext} from 'react'
import {userData} from './Dashboard'
const User=()=>{
    
const {data}= useContext(userData);
return(
    <div>
        hi {data}
    </div>
)
}


export default User;