import React, { useState, createContext } from "react";

import Home from "./Home";

export const userData = React.createContext();
const Dashboard = () => {

const[data,setData]=useState("");

 const handleClick=()=>{
    console.log("data")
    setData("data from dashboard")
  }
  
  return (
    <userData.Provider value={{data}}>
      <div>
        <button onClick={()=>{handleClick()}}>Click here</button>
        <Home />
      </div>
    </userData.Provider>
  );
};

export default Dashboard;
