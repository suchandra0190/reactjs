import React,{useEffect, useState} from 'react'
import User from './User';
const Profile=()=>{
    
return(
    <div>
        <User/>
    </div>
)
}


export default Profile;