//remove specific element from an array

const arr=[1,2,7,8,9]
const elementtobeRemobved=7;

const index=arr.indexOf(elementtobeRemobved);

if(index!=-1){
    arr.splice(index,1);
}

console.log(arr)

//remove duplicate

const arr1=[1,2,2,7,6,6,8,9]

const filteredarray= arr.filter((value,key)=>{
    return(arr.indexOf(value)==key)
})

console.log(filteredarray)

//remove first and last element in array

let array = [1, 2, 3, 4, 5];

array.shift(); // Remove the first element
array.pop();   // Remove the last element

console.log(array); // Output: [2, 3, 4]

//closure in js

function A(){
    var x=5
    
    function B(){
        console.log(x);
    }
    return B;
}

var outerfunction=A();// Assigning the returned inner function to a variable
outerfunction();

//object to array

var obj={a:1,b:2,c:3}

var arr4=Object.entries(obj)

console.log(arr)

//array to object

const arr3 = [['a', 1], ['b', 2], ['c', 3]];
const obj = Object.fromEntries(arr);
console.log(obj); // Output: { a: 1, b: 2, c: 3 }


//shallow copy

const originalObjectt = {
    name: "John",
    age: 30,
    address: {
      city: "New York",
      country: "USA"
    }
  };
  
  // Shallow copy
  const shallowCopy = { ...originalObject };
  
  // Modify shallow copy
  shallowCopy.name = "Jane"; // Modify a primitive property
  shallowCopy.address.city = "Los Angeles"; // Modify a nested property

  console.log("Original Object:", originalObject);
//   Original Object: {
//     name: 'John',
//     age: 30,
//     address: { city: 'Los Angeles', country: 'USA' }
//   }


//Deep copy

const originalObject = {
    name: "John",
    age: 30,
    address: {
      city: "New York",
      country: "USA"
    }
  };
  const Copy = JSON.parse(JSON.stringify(originalObject)) ;
  
  Copy.name = "Jane"; // Modify a primitive property
  Copy.address.city = "Los Angeles"; // Modify a nested property
  
  // Output shallow copy and original object
  console.log("Original Object:", originalObject);
//   Original Object: {
//     name: 'John',
//     age: 30,
//     address: { city: 'New York', country: 'USA' }
//   }


//object destructuring

const object={fname:'suchandra',lsname:'das'}

const{fname,lsname}=object

console.log(fname);

//array destructuring

const array1=['suchandra','Das']

const[name,title]=array1

console.log(name);


//rest operator
console.log(sum(1,2,3,4,5,6,7)) //take multiple arguments from a function

function sum(...numbers){
    return numbers.reduce((total,num)=> total+num,0); //iterates in array elements from left to right 
}

//callback function

function A(name,callBack){  //function passed as an argument to another function
    console.log(name);
    callBack();
}
function print(){
    console.log('hi')
}

A('suchandra',print)

//suchandra hi


const animal = {
  eat() {
    console.log("Eating...");
  }
};

const mammal = Object.create(animal);
mammal.walk = function() {
  console.log("Walking...");
};

const dog = Object.create(mammal);
dog.bark = function() {
  console.log("Woof!");
};

dog.bark(); // Woof!
dog.walk(); // Walking... (inherited from mammal)
dog.eat();  // Eating... (inherited from animal)


// prototype inheritence

const person1={
  name:'suchandra'
}

const cat= Object.create(person);
console.log(cat.name)


const obj={
  greet(){
      console.log(`I am'${this.name}`)
  }
}

const person= Object.create(obj);
person.name='suchandra';

person.greet(); //I am suchandra


//prototype inheritance


const person={
  name:'such'
}

console.log(person.__proto__)


let str='aaabnndhmmkkecv'

let unique=str.split('').filter((chr,index,arr)=> arr.indexOf(chr)==index).join('');

console.log(unique)

//unique character


let str1='aaabnndhmmkkecv'

let lettercount={}

for(let chr of str1){
    lettercount[chr]=(lettercount[chr]||0)+1;
}

console.log(lettercount)

//occurance of letter

