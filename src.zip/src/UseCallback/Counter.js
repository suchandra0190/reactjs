import React, { useState, useCallback } from 'react';

function Child({ increment }) {
    console.log('Child rendered');
    return (
        <button onClick={increment}>Increment Count</button>
    );
}

function Parent() {
    const [count, setCount] = useState(0);

    // Memoize the increment function
    const increment = useCallback(() => {
        setCount(prevCount => prevCount + 1);
    }, []); // Empty dependency array means this function is created only once

    return (
        <div>
            <h1>Count: {count}</h1>
            <Child increment={increment} />
        </div>
    );
}

export default Parent;
