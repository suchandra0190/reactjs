// import React, { useState } from 'react'


// const Button=({increment})=>{
//     console.log("buttonCount")
//     return(
//         <div>
//             <button onClick={increment}>Click me</button>
            
//         </div>
//     )
// }
// export default React.memo(Button);


// <div>
//     {render({count,increment,decrement})}
// </div>