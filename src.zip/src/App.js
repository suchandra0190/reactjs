import React, { useState } from "react";
import Child from "./ChildToParent/Child"; // Import the functional component
import Parent from "./ChildToParent/Parent";
import HOC from "./HigherOrderComponent/HOC";
import ClickCounter from "./HigherOrderComponent/ClickCounter";
import HoverCounter from "./HigherOrderComponent/HoverCounter";
import Result from "./UseMemo/Result";
import Name from "./UseMemo/Name";
import ProductDetails from "./CustomHooks/ProductDetails";
import Dashboard from "./ContextAPI/Dashboard";
// import Counter from "./UseCallback/Counter";
import TodoList from "./Todolist/Todolist";
import ControlledComponent from "./ControlledComponent/ControlledComponent";
import UnControlledComponent from "./ControlledComponent/UncontrolledComponent";
import Debouncing from "./Debouncing/Debouncing";
import Throtlling from "./Debouncing/Throtlling";
import SerachfilterNew from "./SearchFilter/SerachfilterNew";
import Searchfilter from "./SearchFilter/Searchfilter";
import Todolist from "./Todolist/Todolist";
import Product from "./ProductAPI/Product";
import { Outlet } from "react-router-dom";
import RenderProps from './Render props/RenderProps'
// import Counter from './UseReducer/Counter'
import CreateTableNew from "./Createtable/CreateTableNew";
import TodoListPractice from "./Todolist/TodoListPractice";
// import Count from "./Lifting state up/Count";
// import Button from "./Lifting state up/Button";
import Counter from './UseCallback/Counter'




function App({ value }) {
  // console.log(value);
  // const country='India'

  const[count,setCount]=useState(0);

  const increment=()=> setCount(count+1);
  const decrement=()=> setCount(count-1);
  return (
    <div className="app">
      <h1>react router example</h1>
      {/* <main>
        <Outlet/>
      </main> */}
      {/* <h1>Hello from App!</h1>
      <ClickCounter/> 
      <HoverCounter/> 
      <Result marks={50} subject='History'/>
      <Name name="Suchandra"/> */}
      {/* <ProductDetails/> */}
      {/* <Dashboard/> */}
      {/* <TodoList/>
      
      <h1>chatgpt code</h1>
      <Searchfilter/> */}
      {/* <Todolist/> */}
      {/* <Product/> */}
      {/* <SerachfilterNew/> */}
      {/* <UnControlledComponent/> */}
      {/* <Parent/> */}
      {/* <Debouncing/> */}
      {/* <Result marks={90} subject='Bengali'/>
      <Name name="Tuhin"/>  */}
      {/* <RenderProps/> */}
      {/* <Counter/> */}
      {/* <CreateTableNew/> */}
      {/* <TodoListPractice/> */}
      {/* <Throtlling/> */}
      <Counter/>

      {/* <div>
        <Count count={count} />  //passing state as props
        <Button increment={increment} decrement={decrement}/>  //passing function as props
      </div> */}

      
    </div>
  );
}

export default App;
