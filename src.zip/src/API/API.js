import axios from 'axios';

// Add a request interceptor
axios.interceptors.request.use(
  function (config) {
    // Log the request URL
    console.log('API Request URL:', config.url);
    // Log the request method and headers (optional)
    console.log('Request Method:', config.method);
    console.log('Request Headers:', config.headers);
    return config;
  },
  function (error) {
    // Log the request error
    console.error('Request Error:', error);
    return Promise.reject(error);
  }
);

// Add a response interceptor
axios.interceptors.response.use(
  function (response) {
    // Log the response URL (axios includes it in the response config)
    console.log('API Response URL:', response.config.url);
    // Log the response data
    console.log('Response Data:', response.data);
    return response;
  },
  function (error) {
    // Log the response error and response object (if available)
    if (error.response) {
      console.error('Response Error:', error.response.status);
      console.error('Response Data:', error.response.data);
    } else {
      console.error('Response Error:', error.message);
    }
    return Promise.reject(error);
  }
);
