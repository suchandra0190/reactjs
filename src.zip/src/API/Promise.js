function fetchData(){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve('data is fetched');
        },2000)
    })
}


//Promise

fetchData().then((result)=>{
    console.log(result)
}).catch((error)=>{
    console.error(error)
})

//async/await

async function newFn(){
   try{
    const response= await fetchData();
    console.log(response);
   }
   catch(error){
        console.error(erro);
   }
}

newFn();